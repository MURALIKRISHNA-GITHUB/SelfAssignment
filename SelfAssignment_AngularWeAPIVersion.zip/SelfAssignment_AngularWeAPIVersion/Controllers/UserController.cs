using Microsoft.AspNetCore.Mvc;


namespace SelfAssignment_AngularWeAPIVersion.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class UserController : ControllerBase
    {
        
        private readonly ILogger<UserController> _logger;

        public UserController(ILogger<UserController> logger)
        {
            _logger = logger;
        }

        [HttpGet(Name = "SaveUserInfo")]
        public bool Save()
        {
            //to do: need to update logic here 
            //UserInfoManagar _userInfoManagar = new();
            //userInfo.CreatedOn = DateTime.Now;
            //userInfo.UpdatedOn = DateTime.Now;

            //// need to map login user name/email/id based on deisgn here..
            //userInfo.CreatedBy = userInfo.FirstName;

            ////Generate Jobject
            //JObject obj = (JObject)JToken.FromObject(userInfo);

            ////Generate JSON file  at root directory - json
            //GenerateJsonFile(obj);
            return true;
        }
    }
}